/**
 * Layer 3 board leaf: one card rendered as real card art on the field.
 *
 * Rules stay out of this component. It only exposes selection and compact
 * card-local action buttons; every click still routes through the engine
 * action dispatcher via the parent selection hook.
 */
import { useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { CardImage } from '../CardImage';
import { useCardFlightHidden } from '../../hooks/useCardFlightHidden';
import { resolveAssetUrl } from '../../lib/assetUrl';
import { cqh } from './boardScale';
import type { CardView } from '../../../board/projection';

export type BoardCardTileSize = 'leader' | 'board' | 'field';

const SIZE_PX: Record<BoardCardTileSize, { width: string; box: string }> = {
  leader: { width: cqh(116), box: cqh(162) },
  board: { width: cqh(116), box: cqh(162) },
  field: { width: cqh(150), box: cqh(210) },
};

export interface BoardCardTileProps {
  card: CardView;
  size?: BoardCardTileSize;
  selectable?: boolean;
  selected?: boolean;
  /** Project rule "dim, don't hide" (see DockHand.tsx) applied to field cards: true while a selection mode is active and this card isn't one of its eligible candidates. */
  dimmed?: boolean;
  /** Marks a card that has a usable [Activate: Main] effect right now. */
  activatable?: boolean;
  attackable?: boolean;
  showBattlePower?: boolean;
  attachedDonSelectable?: boolean;
  attachedDonSelectedCount?: number;
  onSelect?: () => void;
  onActivate?: () => void;
  onAttack?: () => void;
  onAttachedDonSelect?: () => void;
  onZoom?: () => void;
  onHoverStart?: () => void;
  onHoverEnd?: () => void;
  compactBadges?: boolean;
  /** Main-phase Give DON stepper — shown in the stacked hover menu. */
  giveDonControls?: {
    availableActiveDon: number;
    allowReturnGivenDon?: boolean;
    onGive: () => void;
    onReturn: () => void;
  };
}

function CardActionButton({
  iconSrc,
  label,
  ariaLabel,
  title,
  onClick,
}: {
  iconSrc: string;
  label: string;
  ariaLabel: string;
  title: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={(event) => { event.stopPropagation(); onClick(); }}
      aria-label={ariaLabel}
      title={title}
      className="flex h-8 min-w-[7.5rem] items-center gap-1.5 rounded-md border border-rose-200/75 bg-rose-100/95 px-2 text-[0.58rem] font-black uppercase leading-none tracking-[0.04em] text-slate-950 shadow-[0_8px_20px_rgba(0,0,0,0.42)] transition hover:bg-white"
    >
      <img src={iconSrc} alt="" className="h-4 w-4 shrink-0 object-contain" />
      <span className="truncate">{label}</span>
    </button>
  );
}

function GiveDonStepper({
  attachedCount,
  availableActiveDon,
  allowReturnGivenDon = true,
  onGive,
  onReturn,
}: {
  attachedCount: number;
  availableActiveDon: number;
  allowReturnGivenDon?: boolean;
  onGive: () => void;
  onReturn: () => void;
}) {
  return (
    <div
      className="flex h-8 min-w-[7.5rem] items-center gap-1 rounded-md border border-cyan-200/75 bg-cyan-100/95 px-1.5 text-[0.58rem] font-black uppercase leading-none tracking-[0.04em] text-slate-950 shadow-[0_8px_20px_rgba(0,0,0,0.42)]"
      title={`${availableActiveDon} active DON available`}
    >
      <span className="ml-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border border-slate-900/25 bg-white/90 text-[0.5rem] font-black leading-none">D</span>
      <span className="min-w-0 flex-1 truncate">Give DON</span>
      {allowReturnGivenDon && (
        <button
          type="button"
          disabled={attachedCount === 0}
          onClick={(event) => { event.stopPropagation(); onReturn(); }}
          aria-label="Return 1 given DON"
          title="Return 1 given DON"
          className="flex h-5 w-5 shrink-0 items-center justify-center rounded border border-slate-900/20 bg-white/80 text-sm leading-none transition enabled:hover:bg-white disabled:cursor-not-allowed disabled:opacity-35"
        >
          −
        </button>
      )}
      <span className="min-w-[1rem] text-center tabular-nums">{attachedCount}</span>
      <button
        type="button"
        disabled={availableActiveDon === 0}
        onClick={(event) => { event.stopPropagation(); onGive(); }}
        aria-label="Give 1 DON"
        title={`Give 1 DON (${availableActiveDon} available)`}
        className="flex h-5 w-5 shrink-0 items-center justify-center rounded border border-slate-900/20 bg-white/80 text-sm leading-none transition enabled:hover:bg-white disabled:cursor-not-allowed disabled:opacity-35"
      >
        +
      </button>
    </div>
  );
}

function compactPowerLabel(value: number): string {
  const abs = Math.abs(value);
  if (abs < 1000) return value.toLocaleString();
  const thousands = value / 1000;
  return `${Number.isInteger(thousands) ? thousands.toFixed(0) : thousands.toFixed(1).replace(/\.0$/, '')}K`;
}

/** Card art aspect ratio (width/height) — the tile root is square, the art is narrower. */
const CARD_ASPECT = 63 / 88;

/** Long hexagon, pointy on the left and right (points at the vertical mid-edges). */
const KEYWORD_HEX_CLIP = 'polygon(10px 0, calc(100% - 10px) 0, 100% 50%, calc(100% - 10px) 100%, 10px 100%, 0 50%)';

type KeywordKey = 'rush' | 'blocker' | 'doubleAttack' | 'banish' | 'unblockable';

/**
 * Keyword icon image files live in public/ui-icons/. They're loaded as-is and
 * forced white via a CSS filter (brightness(0) invert(1) turns any opaque
 * black/colored icon pure white while preserving transparency), so dropping a
 * differently-colored source file in still renders white. `srcs` has two
 * entries for Double Attack: the same sword file shown twice, side by side.
 */
const WHITE_FILTER = 'brightness(0) invert(1)';

const KEYWORD_ICON: Record<KeywordKey, { name: string; srcs: string[] }> = {
  rush: { name: 'Rush', srcs: ['/ui-icons/keyword-rush.png'] },
  blocker: { name: 'Blocker', srcs: ['/ui-icons/keyword-blocker.png'] },
  doubleAttack: { name: 'Double Attack', srcs: ['/ui-icons/keyword-sword.png', '/ui-icons/keyword-sword.png'] },
  banish: { name: 'Banish', srcs: ['/ui-icons/keyword-banish.png'] },
  unblockable: { name: 'Unblockable', srcs: ['/ui-icons/keyword-unblockable.png'] },
};

/**
 * A single on-field keyword tag (e.g. Rush, Banish), shown as a white icon on
 * an orange, white-outlined hexagon sized to match the other on-card labels
 * (power delta / DON!! x N — text-2xl). The outline is a slightly larger white
 * hexagon behind the orange one (both share the same clip-path), which gives a
 * crisp border that follows the pointy shape — a plain CSS border can't, since
 * clip-path also clips the border. The keyword name is kept as an accessible
 * label/tooltip since the text is now an icon.
 */
function KeywordLabel({ keyword, compact = false }: { keyword: KeywordKey; compact?: boolean }) {
  const { name, srcs } = KEYWORD_ICON[keyword];
  return (
    <span
      className="pointer-events-none inline-block"
      style={{ clipPath: KEYWORD_HEX_CLIP, backgroundColor: '#ffffff', padding: '2px' }}
    >
      <span
        role="img"
        aria-label={name}
        title={name}
        className={['flex items-center justify-center gap-[0.12em] leading-none', compact ? 'px-2 py-0.5 text-sm' : 'px-3 py-1 text-2xl'].join(' ')}
        style={{ clipPath: KEYWORD_HEX_CLIP, backgroundColor: '#f97316' }}
      >
        {srcs.map((src, index) => (
          <img key={index} src={src} alt="" draggable={false} className="block h-[1.4em] w-auto object-contain" style={{ filter: WHITE_FILTER }} />
        ))}
      </span>
    </span>
  );
}

/**
 * Keyword labels stacked into one row at the full "other label" font size,
 * then uniformly scaled DOWN (never up) so the whole row fits the card width.
 * scrollWidth reports the un-transformed layout width, so re-measuring after a
 * scale is stable. Runs on label changes and whenever the card resizes.
 */
function KeywordRow({ labels, maxWidth, compact = false }: { labels: KeywordKey[]; maxWidth: number; compact?: boolean }) {
  const rowRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  useLayoutEffect(() => {
    const el = rowRef.current;
    if (!el) return;
    const natural = el.scrollWidth;
    setScale(natural > 0 && maxWidth > 0 ? Math.min(1, maxWidth / natural) : 1);
  }, [labels, maxWidth]);

  return (
    <div className="flex justify-center overflow-hidden" style={{ width: maxWidth > 0 ? maxWidth : undefined }}>
      <div
        ref={rowRef}
        className="flex flex-nowrap items-center gap-1"
        style={{ transform: `scale(${scale})`, transformOrigin: 'center' }}
      >
        {labels.map((label) => (
          <KeywordLabel key={label} keyword={label} compact={compact} />
        ))}
      </div>
    </div>
  );
}

/** Tracks an element's rendered pixel width via ResizeObserver (for fit-to-width scaling). */
function useElementWidth<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [width, setWidth] = useState(0);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const update = () => setWidth(el.clientWidth);
    update();
    // ResizeObserver is absent in jsdom/SSR — measure once and skip observing.
    if (typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return [ref, width] as const;
}

/** On-field combat keywords to surface as icon labels, in a stable display order. */
function activeKeywords(card: CardView): KeywordKey[] {
  const labels: KeywordKey[] = [];
  // [Rush] only ever matters on the turn the card is played — it is what lets a
  // summoning-sick card attack. The engine leaves summoningSick TRUE on a Rush
  // card and checks the keyword separately (see staticConditionalSelfBuff.test.ts),
  // so summoningSick is exactly "this is still the turn it arrived". Past that the
  // badge is noise on every board, so it is dropped.
  if (card.hasRush && card.summoningSick) labels.push('rush');
  if (card.hasBlocker) labels.push('blocker');
  if (card.hasDoubleAttack) labels.push('doubleAttack');
  if (card.hasBanish) labels.push('banish');
  if (card.isUnblockable) labels.push('unblockable');
  return labels;
}

export function BoardCardTile({
  card,
  size = 'board',
  selectable,
  selected,
  dimmed = false,
  activatable,
  attackable,
  showBattlePower,
  attachedDonSelectable,
  attachedDonSelectedCount = 0,
  onSelect,
  onActivate,
  onAttack,
  onAttachedDonSelect,
  onZoom,
  onHoverStart,
  onHoverEnd,
  compactBadges = false,
  giveDonControls,
}: BoardCardTileProps) {
  const dims = SIZE_PX[size];
  const isField = size === 'field';
  const rested = card.orientation === 'rested';
  const visiblePowerDelta = !showBattlePower && card.powerDelta !== null && card.powerDelta !== 0 ? card.powerDelta : null;
  const visibleCostDelta = !showBattlePower && card.costDelta !== null && card.costDelta !== 0 ? card.costDelta : null;
  const hasCardActions = !!onActivate || !!onAttack || !!onZoom || !!giveDonControls;
  const hasAttachedDon = card.donAttachedCount > 0 && !showBattlePower;
  // Keyword labels are hidden while the battle-power overlay is up so they
  // don't fight the big centered number during a battle.
  const keywordLabels = showBattlePower ? [] : activeKeywords(card);
  // Card's rendered width, so the keyword row can scale down to fit it.
  const [rootRef, tileWidth] = useElementWidth<HTMLDivElement>();
  const attachedDonSelected = attachedDonSelectedCount > 0;
  const hiddenDuringFlight = useCardFlightHidden(card.instanceId);
  const [previewPoint, setPreviewPoint] = useState<{ x: number; y: number } | null>(null);
  const [actionsHovered, setActionsHovered] = useState(false);
  const previewSrc = resolveAssetUrl(card.imageUrl);
  const previewLeft =
    previewPoint && typeof window !== 'undefined'
      ? Math.max(16, Math.min(previewPoint.x - 434, window.innerWidth - 436))
      : 0;
  const previewTop =
    previewPoint && typeof window !== 'undefined'
      ? Math.max(16, Math.min(previewPoint.y - 304, window.innerHeight - 610))
      : 0;
  const compactCardWidth = Math.max(0, tileWidth * CARD_ASPECT);
  const compactCardSideInset = Math.max(0, (tileWidth - compactCardWidth) / 2);
  const compactCostMaxWidth = Math.max(0, compactCardWidth * 0.5);
  const compactPowerMaxWidth = Math.max(0, compactCardWidth * 0.7);
  const compactCostValue = compactBadges && !showBattlePower ? card.cost : null;
  const compactPowerValue = compactBadges && !showBattlePower ? card.power : null;
  const compactPowerText = compactPowerValue !== null ? compactPowerLabel(compactPowerValue) : null;
  const compactTopBadgeStyle = (side: 'left' | 'right', maxWidth: number) => ({
    [side]: compactCardSideInset,
    top: 0,
    maxWidth,
    transform: side === 'left' ? 'translate(-30%, -30%)' : 'translate(30%, -30%)',
  });
  const compactDonBadgeStyle = {
    left: compactCardSideInset,
    top: 'calc(100% + 0.16rem)',
    width: compactCardWidth,
  };
  const compactModifierTone = (delta: number | null) => {
    if (delta === null || delta === 0) return 'border-white/35 bg-black/45 text-white shadow-[0_8px_18px_rgba(0,0,0,0.42)]';
    return delta > 0
      ? 'border-[#00ff47] bg-[#003d16]/86 text-[#00ff47] shadow-[0_8px_18px_rgba(0,0,0,0.5),0_0_16px_rgba(0,255,71,0.36)]'
      : 'border-[#ff1f1f] bg-[#4a0000]/86 text-[#ff1f1f] shadow-[0_8px_18px_rgba(0,0,0,0.5),0_0_16px_rgba(255,31,31,0.36)]';
  };

  return (
    <div
      ref={rootRef}
      data-card-instance-id={card.instanceId}
      onPointerEnter={onHoverStart}
      onPointerLeave={() => {
        onHoverEnd?.();
        setPreviewPoint(null);
      }}
      onMouseEnter={(event) => previewSrc && setPreviewPoint({ x: event.clientX, y: event.clientY })}
      onMouseMove={(event) => previewSrc && setPreviewPoint({ x: event.clientX, y: event.clientY })}
      onMouseLeave={() => setPreviewPoint(null)}
      className={[
        'group relative flex-shrink-0 transition-opacity duration-200',
        hiddenDuringFlight ? 'invisible' : '',
      ].join(' ')}
      // Every field tile (Leader/Character/Stage) is a FIXED cqh(210) square —
      // the exact same box math the Deck/Trash piles use — with no row-height
      // dependency or max caps, so its inner art resolves to cqh(150) x
      // cqh(210), pixel-identical to those piles regardless of row height. The
      // square (vs the piles' 150x210 rect) is transparent padding that lets a
      // rested (rotate-90) card turn without overflowing its neighbours; the
      // visible art size is the same either way. flex-shrink-0 (above) matches
      // the piles so neither is squeezed by the row.
      style={{ width: dims.box, height: dims.box, opacity: dimmed ? 0.35 : undefined }}
    >
      <div
        role={selectable ? 'button' : undefined}
        tabIndex={selectable ? 0 : undefined}
        onClick={selectable ? onSelect : undefined}
        onKeyDown={selectable ? (event) => { if (event.key === 'Enter' || event.key === ' ') onSelect?.(); } : undefined}
        className={[
          'absolute inset-0 flex items-center justify-center transition-transform duration-200',
          rested ? 'rotate-90' : '',
          selectable ? 'cursor-pointer' : '',
        ].join(' ')}
      >
        <div className="relative" style={isField ? { height: '100%', aspectRatio: '63 / 88' } : { width: dims.width }}>
          <CardImage
            src={card.imageUrl}
            alt={card.name}
            className={[
              isField ? 'h-full w-full' : '',
              selected ? 'ring-2 ring-amber-300' : activatable ? 'ring-2 ring-emerald-400' : attackable ? 'ring-2 ring-rose-400' : '',
            ].filter(Boolean).join(' ')}
          />
          {onZoom && (
            <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center bg-black/0 opacity-0 transition group-hover:bg-black/45 group-hover:opacity-100 group-focus-within:bg-black/45 group-focus-within:opacity-100" />
          )}
        </div>
      </div>

      {compactCostValue !== null && (
        <div
          className={[
            'pointer-events-none absolute z-30 truncate rounded-md border px-1 py-[1px] text-center text-[0.52rem] font-black leading-none',
            compactModifierTone(card.costDelta),
          ].join(' ')}
          style={compactTopBadgeStyle('left', compactCostMaxWidth)}
          title={`Cost ${compactCostValue}`}
        >
          {compactCostValue}
        </div>
      )}

      {compactPowerValue !== null && compactPowerText !== null && (
        <div
          className={[
            'pointer-events-none absolute z-30 truncate rounded-md border px-1 py-[1px] text-center text-[0.52rem] font-black leading-none',
            compactModifierTone(card.powerDelta),
          ].join(' ')}
          style={compactTopBadgeStyle('right', compactPowerMaxWidth)}
          title={`Power ${compactPowerValue.toLocaleString()}`}
        >
          {compactPowerText}
        </div>
      )}

      {compactBadges && hasAttachedDon && (
        <button
          type="button"
          disabled={!attachedDonSelectable}
          onClick={(event) => { event.stopPropagation(); onAttachedDonSelect?.(); }}
          className={[
            'absolute z-30 truncate rounded-md border px-1.5 py-0.5 text-center text-[0.58rem] font-black uppercase leading-none text-white shadow-[0_8px_18px_rgba(0,0,0,0.5)] transition',
            attachedDonSelectable ? 'cursor-pointer hover:border-white hover:bg-black' : 'cursor-default',
            attachedDonSelected
              ? 'border-white bg-black ring-2 ring-white/70'
              : 'border-white/45 bg-black',
          ].join(' ')}
          style={compactDonBadgeStyle}
          aria-label={`${card.donAttachedCount} attached DON on ${card.name}`}
          title={attachedDonSelectable ? 'Select attached DON!!' : `${card.donAttachedCount} attached DON!!`}
        >
          DON <span className="align-[0.08em] text-[0.4rem]">x</span> {card.donAttachedCount}
          {/* How many of this pile are selected, not just that some are. The
              compact badge is the only control mobile has for an attached
              pile — one tap takes one more DON!! — so without the running
              count a second tap gives no feedback that anything happened. */}
          {attachedDonSelected && (
            <span className="ml-1 rounded-sm bg-white px-1 py-[1px] text-[0.5rem] text-black">{attachedDonSelectedCount}</span>
          )}
        </button>
      )}

      {compactBadges && keywordLabels.length > 0 && (
        <div className="absolute left-1/2 top-1/2 z-30 -translate-x-1/2 -translate-y-1/2">
          <KeywordRow labels={keywordLabels} maxWidth={Math.max(0, compactCardWidth - 6)} compact />
        </div>
      )}

      {!compactBadges && (visiblePowerDelta !== null || visibleCostDelta !== null || hasAttachedDon || keywordLabels.length > 0) && (
        <div className={['absolute left-1/2 top-1/2 z-30 flex -translate-x-1/2 -translate-y-1/2 flex-col items-center', compactBadges ? 'gap-1' : 'gap-1.5'].join(' ')}>
          {visiblePowerDelta !== null && (
            <div
              className={[
                'pointer-events-none rounded-lg border font-black leading-none shadow-[0_12px_30px_rgba(0,0,0,0.55)]',
                compactBadges ? 'px-2 py-1 text-sm' : 'px-3 py-1.5 text-2xl',
                visiblePowerDelta > 0
                  ? 'border-[#00ff47] bg-[#003d16]/80 text-[#00ff47] shadow-[0_12px_30px_rgba(0,0,0,0.55),0_0_24px_rgba(0,255,71,0.42)]'
                  : 'border-[#ff1f1f] bg-[#4a0000]/80 text-[#ff1f1f] shadow-[0_12px_30px_rgba(0,0,0,0.55),0_0_24px_rgba(255,31,31,0.42)]',
              ].join(' ')}
            >
              {visiblePowerDelta > 0 ? '+' : ''}{visiblePowerDelta.toLocaleString()}
            </div>
          )}

          {visibleCostDelta !== null && (
            <div
              className={[
                'pointer-events-none rounded-lg border font-black leading-none shadow-[0_12px_30px_rgba(0,0,0,0.55)]',
                compactBadges ? 'px-2 py-1 text-sm' : 'px-3 py-1.5 text-2xl',
                visibleCostDelta > 0
                  ? 'border-[#ffffff] bg-black text-white shadow-[0_12px_30px_rgba(0,0,0,0.55),0_0_22px_rgba(255,255,255,0.24)]'
                  : 'border-[#00d5ff] bg-[#001f33]/90 text-[#00d5ff] shadow-[0_12px_30px_rgba(0,0,0,0.55),0_0_24px_rgba(0,213,255,0.36)]',
              ].join(' ')}
            >
              {visibleCostDelta > 0 ? '+' : ''}{visibleCostDelta}
            </div>
          )}

          {hasAttachedDon && (
            <button
              type="button"
              disabled={!attachedDonSelectable}
              onClick={(event) => { event.stopPropagation(); onAttachedDonSelect?.(); }}
              className={[
                'rounded-lg border font-black uppercase leading-none text-white shadow-[0_12px_30px_rgba(0,0,0,0.55)] transition',
                compactBadges ? 'px-2 py-1 text-[0.72rem]' : 'px-3 py-1.5 text-[1.2rem]',
                attachedDonSelectable ? 'cursor-pointer hover:border-white hover:bg-black' : 'cursor-default',
                attachedDonSelected
                  ? 'border-white bg-black ring-2 ring-white/70'
                  : 'border-white/45 bg-black',
              ].join(' ')}
              aria-label={`${card.donAttachedCount} attached DON on ${card.name}`}
              title={attachedDonSelectable ? 'Select attached DON!!' : `${card.donAttachedCount} attached DON!!`}
            >
              DON <span className={compactBadges ? 'align-[0.08em] text-[0.48rem]' : 'align-[0.08em] text-[0.7rem]'}>x</span> {card.donAttachedCount}
            </button>
          )}

          {keywordLabels.length > 0 && <KeywordRow labels={keywordLabels} maxWidth={Math.max(0, tileWidth * CARD_ASPECT - 6)} compact={compactBadges} />}
        </div>
      )}

      {showBattlePower && card.power !== null && (
        <div className={['pointer-events-none absolute left-1/2 top-1/2 z-30 -translate-x-1/2 -translate-y-1/2 rounded-lg border-2 border-[#ff1f1f] bg-[#5a0000]/68 font-black leading-none text-[#ff1f1f] shadow-[0_12px_30px_rgba(0,0,0,0.58),0_0_30px_rgba(255,31,31,0.5)] backdrop-blur-md', compactBadges ? 'px-2.5 py-1.5 text-base' : 'px-3.5 py-2 text-2xl'].join(' ')}>
          {card.power.toLocaleString()}
        </div>
      )}

      {hasCardActions && (
        <div
          className="absolute right-1 top-1/2 z-40 flex -translate-y-1/2 flex-col items-stretch gap-1 opacity-0 transition group-hover:opacity-100 group-focus-within:opacity-100"
          onMouseEnter={() => {
            setActionsHovered(true);
            setPreviewPoint(null);
          }}
          onMouseLeave={() => setActionsHovered(false)}
        >
          {onAttack && (
            <CardActionButton
              iconSrc="/ui-icons/action-attack.png"
              label="Attack"
              ariaLabel={`Declare attack with ${card.name}`}
              title="Declare attack"
              onClick={onAttack}
            />
          )}
          {giveDonControls && (
            <GiveDonStepper
              attachedCount={card.donAttachedCount}
              availableActiveDon={giveDonControls.availableActiveDon}
              allowReturnGivenDon={giveDonControls.allowReturnGivenDon}
              onGive={giveDonControls.onGive}
              onReturn={giveDonControls.onReturn}
            />
          )}
          {onActivate && (
            <CardActionButton
              iconSrc="/ui-icons/action-activate-main.png"
              label="Activate: Main"
              ariaLabel={`Activate effect of ${card.name}`}
              title="Activate: Main"
              onClick={onActivate}
            />
          )}
          {onZoom && (
            <CardActionButton
              iconSrc="/ui-icons/action-view-detail.png"
              label="View Detail"
              ariaLabel={`View details for ${card.name}`}
              title="View detail"
              onClick={onZoom}
            />
          )}
        </div>
      )}

      {previewSrc && previewPoint && !actionsHovered && typeof document !== 'undefined' && createPortal(
        <div
          className="pointer-events-none fixed z-[230] hidden w-[26rem] max-w-[min(26rem,calc(100vw-2rem))] overflow-visible sm:block"
          style={{ left: previewLeft, top: previewTop }}
        >
          <img src={previewSrc} alt="" className="h-auto w-full object-contain drop-shadow-[0_18px_44px_rgba(0,0,0,0.65)]" />
        </div>,
        document.body,
      )}
    </div>
  );
}
