/**
 * One player's half of the playmat, matching the official play sheet:
 * Character Area across the top (Deck now sits beside it as its own sibling
 * box, pinned to one edge — see characterRow below), Life down the left
 * side, and the
 * leader's row in the middle-right holding Leader/Stage/Trash plus the
 * Active/Rested DON!! piles as further columns (moved in from a standalone
 * column outside the mat — see MatchScreen.tsx history — so the whole "my
 * own resources" row reads left-to-right in one place). Cost Area taps
 * still route through onCardTap('costArea', card) exactly like
 * Leader/Character taps; only the visual position moved. The hand is not
 * printed on the sheet, so it stays outside the mat edge for playability.
 * There's no separate "P1 / Life" label row anymore — Life is the count
 * badge on the Life pile itself, and player identity is shown by
 * MatchScreen.tsx's HandSection header instead.
 *
 * The DON!! Deck pile no longer lives in this row — it's rendered inside the
 * Life cell instead (see LifeStack), pinned to that cell's bottom edge,
 * since both are sealed/unbrowsable piles a player rarely touches directly.
 * The Active/Rested DON!! piles both stack sideways now and render at full
 * card size (DonChip.tsx), with their MatCell wrappers made visually
 * invisible (variant="invisible") so only the chips themselves show on the
 * mat — see donGroup below. Leader's MatCell is invisible for a different
 * reason: BoardCardTile's stat badges (cost/power/counter) sit on negative
 * offsets just outside the card's own box, and MatCell's default chrome
 * clips anything past its edge via overflow-hidden — variant="invisible"
 * drops that clipping the same way it already does for the DON!! cells.
 *
 * Within boardRow, the DON!! group and the Stage+Trash group are each
 * independently anchored to the screen edge they thematically belong next to
 * (DON!! near Life, Stage+Trash on the opposite edge) rather than living
 * inside one centered block — see the boardRow assembly below for exactly
 * how. Trash now sits in the slot Deck used to occupy here (Deck moved up to
 * the Character Area row instead); see TrashPile.tsx for why it shows real
 * face-up card art rather than a sealed back like Deck/DON!! Deck.
 *
 * This component is presentational. It keeps the same tap/zoom callbacks and
 * selection predicates as before; rules still live in the engine. The
 * hover/focus card-preview side panel that used to live in MatchScreen.tsx
 * has been removed; card zoom (onCardZoom) is the one remaining detail-view
 * affordance. The Trash gallery popup (TrashGalleryModal) is the one other
 * piece of local-only UI state this component owns — opening/closing it
 * never touches game state, exactly like onCardZoom.
 */
import { memo, useEffect, useRef, useState } from 'react';
import type { CSSProperties, ReactNode } from 'react';
import { AttachedDonHoverStack } from './AttachedDonHoverStack';
import { useSeatDonArtUrl } from './MatchAccessoriesContext';
import { BoardCardTile } from './BoardCardTile';
import { CardBackArt } from './CardBackArt';
import { CardImage } from '../CardImage';
import { cqh } from './boardScale';
import { CountBadge } from './CountBadge';
import { DonStack } from './DonStack';
import { PileStack } from './PileStack';
import { TrashGalleryModal } from './TrashGalleryModal';
import { TrashPile } from './TrashPile';
import type { BoardSelectionMode } from './useBoardSelection';
import type { CardView, PlayerBoardView } from '../../../board/projection';
import { countAvailableDon } from '../../../board/projection';

export interface PlayerBoardPanelProps {
  board: PlayerBoardView;
  isOwn: boolean;
  isOpponent: boolean;
  /**
   * Purely spatial: true for the far/top screen slot. The hand stays on that
   * player's outside edge while the printed mat stays intact.
   */
  reverseRows: boolean;
  mode: BoardSelectionMode;
  /** True for own in-play cards whose curated program exposes an [Activate: Main] ability. */
  canActivateCard?: (card: CardView) => boolean;
  /** True for own in-play cards whose curated program exposes an [On Your Opponent's Attack] ability. */
  canOnOppAttackCard?: (card: CardView) => boolean;
  canAttackCard?: (card: CardView) => boolean;
  battlePowerInstanceIds?: Set<string>;
  /** Passed down to PileStack — hides ghost layers while board is active. */
  boardFocused?: boolean;
  /**
   * ownerPlayerId is supplied by THIS component (from its own `board.playerId`
   * prop) rather than pre-bound by the caller into a wrapper closure — see
   * docs/08-match-performance-plan.md Phase 1. Passing the raw, stable
   * useBoardSelection function straight through (e.g. `onCardTap={selection.handleCardTap}`)
   * lets MatchScreen avoid creating a new per-render closure just to bind
   * "which side this panel is" ahead of time.
   */
  onCardTap: (ownerPlayerId: string, zone: 'hand' | 'leaderArea' | 'characterArea' | 'stageArea' | 'costArea' | 'attachedDon', card: CardView) => void;
  onCardAttack?: (card: CardView) => void;
  /** See onCardTap's doc comment — same ownerPlayerId-supplied-internally pattern. Currently unused by this component's own render (kept for the mobile board's equivalent flow); still declared here so its identity is stabilizable at the call site. */
  onAttachedDonLabelTap?: (ownerPlayerId: string, card: CardView) => void;
  onCardZoom: (card: CardView) => void;
  onAttackTargetHover?: (card: CardView | null) => void;
  /** See onCardTap's doc comment — `board` is supplied internally (this component already has it as a prop) instead of being pre-bound by the caller. */
  canGiveDonOnCard?: (board: PlayerBoardView, card: CardView) => boolean;
  onGiveDon?: (board: PlayerBoardView, card: CardView) => void;
  onReturnGivenDon?: (card: CardView) => void;
  /** Hotseat-only undo for mis-clicks; disabled in Casual matches. */
  allowReturnGivenDon?: boolean;
}

/**
 * Exported because the mobile mat (MatchScreen's MobileCardZone) must ask the
 * exact same question about the exact same modes. It used to keep a private
 * `mobileLeaderCharacterSelectable` copy of this switch, and the copy silently
 * fell behind: it had no 'resolvingFieldChoice' case, so on mobile an effect
 * that asks you to pick a Character on the field ("K.O. up to 1 of your
 * opponent's Characters") rendered the banner and dimmed nothing, and no card
 * was tappable — the choice was unresolvable. One shared function instead, so a
 * new selection mode can't be wired into one breakpoint only.
 */
export function leaderCharacterSelectable(
  mode: BoardSelectionMode,
  isOwn: boolean,
  isOpponent: boolean,
  zone: 'leaderArea' | 'characterArea' | 'stageArea',
  card: CardView,
  canActivate: boolean,
  canOnOppAttack: boolean,
): boolean {
  switch (mode.kind) {
    case 'selectAttacker':
      return zone !== 'stageArea' && isOwn && card.orientation === 'active' && !card.summoningSick;
    case 'selectAttackTarget':
      if (!isOpponent) return false;
      // A forced-target effect (OP17-044 Captain John) narrows the legal set to
      // exactly one Character. declareAttack already refuses everything else, so
      // offering the Leader and every rested Character here just produced a
      // validation error on tap that reads as "I can't attack at all".
      if (mode.forcedTargetInstanceId) return card.instanceId === mode.forcedTargetInstanceId;
      if (zone === 'leaderArea') return true;
      return zone === 'characterArea' && card.orientation === 'rested';
    case 'selectBlocker':
      return isOwn && zone === 'characterArea' && card.orientation === 'active' && card.hasBlocker;
    case 'selectActivateSource':
      // The "Activate Effect" flow: own Leader/Character with a curated [Activate: Main] ability.
      return isOwn && canActivate;
    case 'selectOnOppAttackSource':
      return isOwn && canOnOppAttack;
    case 'resolvingFieldChoice':
      // Unlike every other case here, NOT gated on isOwn — a field choice's
      // candidates can belong to either player (e.g. "K.O. up to 1 opponent
      // Character"); candidateInstanceIds is the sole authority.
      // Already-selected cards stay selectable so they can be tapped off again;
      // a candidate that would break the combined budget is not pickable.
      if (mode.selectedIds.includes(card.instanceId)) return true;
      if (mode.blockedInstanceIds.includes(card.instanceId)) return false;
      return mode.candidateInstanceIds.includes(card.instanceId);
    case 'idle':
      // Idle: an own card with a ready [Activate: Main] effect is tappable directly (the ⚡ badge).
      return isOwn && canActivate;
    default:
      return false;
  }
}

/**
 * "Dim, don't hide" for field cards (mirrors DockHand's `dimmed` for hand
 * cards): true for every card on EITHER board that is not one of the
 * current field choice's candidates, so the eligible card(s) visually pop
 * out of the rest of the mat. Deliberately independent of `isOwn`/selectable
 * — an online opponent's client renders this identically (see
 * BoardSelectionMode's 'resolvingFieldChoice' doc comment), it just can't
 * click through it.
 */
export function fieldChoiceDimmed(mode: BoardSelectionMode, card: CardView): boolean {
  if (mode.kind !== 'resolvingFieldChoice') return false;
  // Already picked: never dim — it carries the selected ring instead.
  if (mode.selectedIds.includes(card.instanceId)) return false;
  // Not a candidate at all, OR a candidate the current selection has priced out
  // of the combined budget ("a total cost of 4 or less"). Both read the same to
  // the player: this card cannot be chosen right now.
  return !mode.candidateInstanceIds.includes(card.instanceId)
    || mode.blockedInstanceIds.includes(card.instanceId);
}

/** True while `card` is one of the current field choice's picked cards (drives the selected ring). */
export function fieldChoiceSelected(mode: BoardSelectionMode, card: CardView): boolean {
  return mode.kind === 'resolvingFieldChoice' && mode.selectedIds.includes(card.instanceId);
}

function selectedAttackerIds(mode: BoardSelectionMode): Set<string> {
  if (mode.kind === 'selectAttackTarget') return new Set([mode.attackerInstanceId]);
  return new Set();
}

// Moved verbatim from MatchScreen.tsx's old DonManagementColumn/DonCardStack
// (now living in the leader's row instead of a standalone column) — same
// rule, just relocated alongside leaderCharacterSelectable above.
function donSelectable(mode: BoardSelectionMode, isOwn: boolean, card: CardView): boolean {
  if (!isOwn) return false;
  if (mode.kind === 'payingActivateEffectCost' || mode.kind === 'payingOnOppAttackCost') {
    return true;
  }
  if (mode.kind === 'payingEventMainCost') return mode.candidateInstanceIds.includes(card.instanceId);
  if (mode.kind === 'payingCounterEventCost') return mode.candidateInstanceIds.includes(card.instanceId);
  // donMinus pending choice: only the choice's own candidate DON!! are
  // pickable — candidateInstanceIds already encodes activeOnly (see
  // interpreter.ts's suspendOrPayAbilityCost / donMinusCandidateIds), so a
  // rested Cost Area DON!! simply won't appear here when the cost requires
  // active DON!! specifically.
  if (mode.kind === 'resolvingDonChoice') return mode.candidateInstanceIds.includes(card.instanceId);
  return false;
}

function selectedDonInstanceIds(mode: BoardSelectionMode): Set<string> {
  if (mode.kind === 'payingActivateEffectCost') return new Set(mode.selectedDonIds);
  if (mode.kind === 'payingOnOppAttackCost') return new Set(mode.selectedDonIds);
  if (mode.kind === 'payingEventMainCost') return new Set(mode.selectedDonIds);
  if (mode.kind === 'payingCounterEventCost') return new Set(mode.selectedDonIds);
  if (mode.kind === 'resolvingDonChoice') return new Set(mode.selectedDonIds);
  return new Set();
}

function attachedDonIds(board: PlayerBoardView): Set<string> {
  const ids = new Set<string>();
  for (const id of board.leader?.donAttachedIds ?? []) ids.add(id);
  for (const character of board.characterArea) {
    for (const id of character.donAttachedIds) ids.add(id);
  }
  return ids;
}

// Raw px-equivalent constants, kept as plain numbers so ratio math (the
// DON!! Deck's 0.8x, the Life fan's per-card offset, etc.) stays exact —
// see boardScale.ts. Only at the point a value is actually assigned to a
// style do we wrap it in cqh(), so it scales with the board's live height.
const FIELD_CARD_WIDTH_PX = 150;
const FIELD_CARD_HEIGHT_PX = 210;
const BOARD_ZONE_TRACK_PX = 210;
const FIELD_CARD_WIDTH = cqh(FIELD_CARD_WIDTH_PX);
const FIELD_CARD_HEIGHT = cqh(FIELD_CARD_HEIGHT_PX);
const BOARD_ZONE_TRACK = cqh(BOARD_ZONE_TRACK_PX);
// A Life card lies sideways (90deg, same convention as a rested field card).
// Rotating swaps its bounding box: what was FIELD_CARD_WIDTH_PX (150) tall
// becomes the on-screen width, and what was FIELD_CARD_HEIGHT_PX (210) wide
// becomes the on-screen height... i.e. a full-size rotated card's footprint
// is FIELD_CARD_HEIGHT_PX wide x FIELD_CARD_WIDTH_PX tall. The card is kept
// at its FULL/unscaled size — the Life column's own grid track
// (LIFE_COLUMN_TRACK_PX below) is widened to fit that footprint instead of
// shrinking the card down to the old upright-card column width.
const LIFE_COLUMN_TRACK_PX = FIELD_CARD_HEIGHT_PX + 20;
const LIFE_COLUMN_TRACK = cqh(LIFE_COLUMN_TRACK_PX);
// DON!! Deck visual (inside LifeStack) reads 20% smaller than a Life/field
// card — it's a sealed pile a player barely touches, so it doesn't need to
// read at full card size the way Active/Rested DON!! chips now do.
const DON_DECK_CARD_WIDTH = cqh(FIELD_CARD_WIDTH_PX * 0.8);

/**
 * Thin pass-through wrapper around a Leader/Character BoardCardTile that
 * registers its own real DOM node (via registerEl) so PlayerBoardPanel can
 * get an accurate getBoundingClientRect() for anchoring AttachedDonHoverStack
 * — see registerCardEl/revealAttachedDonStack above. Same box-sizing
 * classes BoardCardTile's own root already uses in this flex-row context
 * (h-full so it fills the row's height, flex-shrink-0 so it doesn't get
 * squeezed), so inserting it changes nothing visually; it only adds one
 * more DOM node whose rect we can read directly instead of searching the
 * document for it.
 */
function HoverableFieldCard({
  instanceId,
  registerEl,
  active,
  onEnter,
  onLeave,
  children,
}: {
  instanceId: string;
  registerEl: (instanceId: string, el: HTMLDivElement | null) => void;
  active: boolean;
  onEnter: () => void;
  onLeave: () => void;
  children: ReactNode;
}) {
  return (
    <div
      ref={(el) => registerEl(instanceId, el)}
      // `flex items-center` matters: this wrapper is h-full (it stretches to
      // the zone's row height) but BoardCardTile's root is a FIXED square box,
      // so as a plain block the card sat at the top of the stretched wrapper
      // and read as vertically off-centre in its field. The parent's
      // items-center only centres this wrapper, which fills the row, not the
      // fixed-size card inside it — so the centring has to happen here.
      className="flex h-full flex-shrink-0 items-center justify-center"
      onMouseEnter={active ? onEnter : undefined}
      onMouseLeave={active ? onLeave : undefined}
    >
      {children}
    </div>
  );
}

function EmptySlot({ label }: { size: 'leader' | 'board'; label: string }) {
  return (
    <div
      className="flex flex-shrink-0 items-center justify-center rounded-lg border border-dashed border-white/15 text-center text-[9px] font-black uppercase leading-tight tracking-wide text-white/25"
      style={{ width: FIELD_CARD_WIDTH, height: FIELD_CARD_HEIGHT }}
    >
      {label}
    </div>
  );
}

function LifeStack({ playerId, life, count, donDeckCount, donDeckFirst = false }: { playerId: string; life: CardView[]; count: number; donDeckCount: number; donDeckFirst?: boolean }) {
  const visibleCards = Math.max(0, Math.min(count, 5));
  const slots = Array.from({ length: visibleCards });

  return (
    <div
      className="relative h-full flex-shrink-0"
      style={{ width: FIELD_CARD_HEIGHT }}
      aria-label={`${count} Life cards`}
      data-board-zone="life"
      data-board-player={playerId}
    >
      {slots.map((_, index) => {
        // life[index] lines up with this slot 1:1 (both walk top-of-stack
        // first). A card turned face-up by an effect (e.g. "turn the top
        // Life card face-up") shows its real art here instead of a sealed
        // back — Life is otherwise secret (3-1-5), so every other slot stays
        // CardBackArt regardless of debug "both hands visible" posture.
        const card = life[index];
        const faceUp = card?.faceState === 'faceUp';
        // Life cards lie sideways now (same 90deg rotation as a rested field
        // card), rendered at FULL size — the anchor is sized to the rotated
        // card's actual footprint (FIELD_CARD_HEIGHT wide x FIELD_CARD_WIDTH
        // tall, since rotating swaps the two) rather than shrinking the card
        // to fit the old upright-card width. The Life column's own grid
        // track (LIFE_COLUMN_TRACK) was widened to match, so this footprint
        // fits without being clipped. The fan offset itself keeps stepping
        // in the same direction as before (top/bottom, by index) — only the
        // card's own orientation/size changed. Index 0 is the top of the
        // Life stack (zone.ts "cardIds[0] = top of stack" convention) and
        // gets the HIGHEST z-index so it renders as the frontmost card,
        // matching a real fanned pile.
        return (
          <div
            key={card?.instanceId ?? index}
            className="absolute left-0 right-0 mx-auto flex items-center justify-center"
            style={{
              [donDeckFirst ? 'bottom' : 'top']: cqh(index * 18),
              width: FIELD_CARD_HEIGHT,
              height: FIELD_CARD_WIDTH,
              zIndex: visibleCards - index,
            }}
            aria-label={faceUp ? card.name : undefined}
          >
            <div className="rotate-90" style={{ width: FIELD_CARD_WIDTH }}>
              <div className="aspect-[63/88] overflow-hidden rounded shadow-[0_4px_10px_rgba(0,0,0,0.38)]">
                {faceUp ? <CardImage src={card.imageUrl} alt={card.name} className="h-full w-full" /> : <CardBackArt tone="navy" playerId={playerId} />}
              </div>
            </div>
          </div>
        );
      })}
      {/* Single count overlay for the whole fan (same CountBadge used by
          PileStack/DonStack) — replaces the old "0"-only fallback, shown
          regardless of count so Life always reads a number. */}
      <CountBadge count={count} />

      {/* DON!! Deck, relocated here by design: it rides inside the Life cell
          (which doesn't move) pinned to the cell's own bottom edge, sized
          20% smaller than a Life/field card. Uses the teal colorway of
          CardBackArt (distinct from the navy Life/Deck card back) so this
          pile reads as its own zone.
          Known limitation: with a full 5-card Life fan, the bottom-pinned
          DON!! card can visually overlap the lowest Life card on very short
          viewports — z-index keeps the DON!! card on top, but this hasn't
          been measured/avoided dynamically. */}
      <div
        className={['absolute inset-x-0 mx-auto aspect-[63/88] overflow-hidden rounded shadow-[0_4px_10px_rgba(0,0,0,0.45)]', donDeckFirst ? 'top-0' : 'bottom-0'].join(' ')}
        style={{ width: DON_DECK_CARD_WIDTH, zIndex: 10 }}
        aria-label={`${donDeckCount} DON!! Deck`}
        data-board-zone="donDeck"
        data-board-player={playerId}
        data-board-card-anchor
      >
        <CardBackArt tone="teal" playerId={playerId} />
        <CountBadge count={donDeckCount} />
      </div>
    </div>
  );
}

function MatCell({
  label,
  children,
  className = '',
  variant = 'light',
  labelClassName = '',
  style,
  allowOverflow = false,
  padding = 'p-2',
}: {
  label: string;
  children?: ReactNode;
  className?: string;
  /** 'invisible' drops the border/background chrome but keeps the same layout box (used for the Active/Rested DON!! cells, which should show only the chips). */
  variant?: 'light' | 'dark' | 'invisible';
  labelClassName?: string;
  /** Explicit sizing (e.g. a fixed cqh() width) for cells that must match another cell's box exactly rather than shrink-to-fit their content — see deckCell. */
  style?: CSSProperties;
  /** When true, removes overflow-hidden so children (e.g. the stacked deck ghost layers) can render outside the cell boundary without being clipped. */
  allowOverflow?: boolean;
  /** Padding utility for the cell box; pass 'p-0' for a full-bleed card (e.g. Stage). */
  padding?: string;
}) {
  const isInvisible = variant === 'invisible';

  return (
    <section
      style={style}
      className={[
        'relative flex min-h-0 min-w-0 items-center justify-center rounded-lg',
        padding,
        isInvisible ? 'border-0 bg-transparent' : (allowOverflow ? 'border' : 'overflow-hidden border'),
        variant === 'dark' ? 'border-white/10 bg-white/12' : variant === 'light' ? 'border-white/15 bg-white/[0.05]' : '',
        className,
      ].join(' ')}
    >
      <span className={['pointer-events-none absolute left-2 top-1.5 z-0 text-[9px] font-black uppercase tracking-[0.18em] text-white/20', labelClassName].join(' ')}>{label}</span>
      <div className="relative z-10 flex h-full w-full min-h-0 min-w-0 items-center justify-center gap-2">{children}</div>
    </section>
  );
}

/**
 * Wrapped in React.memo (default shallow prop comparison) — this is the
 * primary re-render firewall for the board: as of Phase 1, every prop
 * passed in from MatchScreen/PlayerSideRow is reference-stable when
 * nothing relevant to THIS side changed (see docs/08-match-performance-plan.md),
 * so a re-render triggered by unrelated MatchScreen state (mobile panel
 * toggle, chat, hover elsewhere) no longer re-renders this panel — or
 * anything inside it (BoardCardTile/DonStack/PileStack per card) — at all.
 */
export const PlayerBoardPanel = memo(function PlayerBoardPanel({ board, isOwn, isOpponent, reverseRows, mode, canActivateCard, canOnOppAttackCard, canAttackCard, battlePowerInstanceIds, boardFocused = false, onCardTap, onCardAttack, onAttachedDonLabelTap, onCardZoom, onAttackTargetHover, canGiveDonOnCard, onGiveDon, onReturnGivenDon, allowReturnGivenDon = true }: PlayerBoardPanelProps) {
  const attackerSelected = selectedAttackerIds(mode);
  // Mark/select own in-play cards that can activate a [Activate: Main] effect.
  const canActivate = (card: CardView): boolean => isOwn && !!canActivateCard?.(card);
  const canOnOppAttack = (card: CardView): boolean => isOwn && !!canOnOppAttackCard?.(card);
  const canAttack = (card: CardView): boolean => isOwn && !!canAttackCard?.(card);
  const availableActiveDon = countAvailableDon(board);
  const giveDonControlsFor = (card: CardView) =>
    canGiveDonOnCard?.(board, card)
      ? {
          availableActiveDon,
          allowReturnGivenDon,
          onGive: () => onGiveDon?.(board, card),
          onReturn: () => onReturnGivenDon?.(card),
        }
      : undefined;
  const donArtUrl = useSeatDonArtUrl(board.playerId);
  const leaderCard: CardView | null = board.leader;
  const stageCard: CardView | null = board.stageArea[0] ?? null;
  const attachedDon = attachedDonIds(board);
  const unattachedDon = board.costArea.filter((don) => !attachedDon.has(don.instanceId));
  const activeDon = unattachedDon.filter((don) => !don.donRested);
  const restedDon = unattachedDon.filter((don) => don.donRested);
  const selectedDon = selectedDonInstanceIds(mode);
  const [trashGalleryOpen, setTrashGalleryOpen] = useState(false);
  const attachedDonSelectable = (card: CardView): boolean =>
    isOwn && (mode.kind === 'payingActivateEffectCost' || mode.kind === 'payingOnOppAttackCost' || mode.kind === 'payingEventMainCost' || mode.kind === 'payingCounterEventCost' || mode.kind === 'resolvingDonChoice') && card.donAttachedCount > 0;
  const selectedAttachedDonCount = (card: CardView): number =>
    card.donAttachedIds.filter((id) => selectedDon.has(id)).length;

  // Attached DON!! hover stack (see AttachedDonHoverStack.tsx doc comment):
  // replaces the old "tap the DON!! x N badge to bulk-select" flow with
  // per-DON!! chip selection, revealed by hovering the owning Leader/
  // Character (desktop) or tapping its badge (touch — no hover to fire).
  // Purely local UI state; never touches GameState, same as trashGalleryOpen
  // above and onCardZoom throughout this file.
  const [donStackCard, setDonStackCard] = useState<CardView | null>(null);
  const [donStackAnchor, setDonStackAnchor] = useState<{ x: number; y: number } | null>(null);
  // instanceId -> CardView for every DON!! this player owns, attached or
  // not — board.costArea already includes attached DON!! (attachment is
  // layered on top via CardInstance.donAttached, not a separate zone; see
  // zoneView.ts), so this is a plain lookup, not a second projection.
  const donCardById = new Map(board.costArea.map((don) => [don.instanceId, don]));
  // Real DOM nodes for every Leader/Character card this panel renders,
  // registered by HoverableFieldCard's ref callback below. Looking these up
  // directly (instead of a global document.querySelector by
  // data-card-instance-id) sidesteps any chance of a stale/duplicate DOM
  // match and keeps the anchor calculation working even if this panel is
  // portal-nested or re-parented later.
  const cardElRefs = useRef(new Map<string, HTMLDivElement>());
  function registerCardEl(instanceId: string, el: HTMLDivElement | null): void {
    if (el) cardElRefs.current.set(instanceId, el);
    else cardElRefs.current.delete(instanceId);
  }
  // The hover stack renders into a portal a few px below the card, so the
  // pointer has to cross a small physical gap to reach it — without a grace
  // window, leaving the card's own hitbox (even briefly, mid-transit toward
  // the stack) would fire hideAttachedDonStack and the stack would vanish
  // out from under the cursor before the click lands. Cleared by both
  // revealAttachedDonStack (re-entering the card) and the stack's own
  // onMouseEnter (successfully reaching it).
  const donStackCloseTimerRef = useRef<number | null>(null);

  function clearDonStackCloseTimer(): void {
    if (donStackCloseTimerRef.current !== null) {
      window.clearTimeout(donStackCloseTimerRef.current);
      donStackCloseTimerRef.current = null;
    }
  }
  function revealAttachedDonStack(card: CardView): void {
    clearDonStackCloseTimer();
    const portalEl = document.getElementById('board-overlay-root');
    const cardEl = cardElRefs.current.get(card.instanceId);
    if (!portalEl || !cardEl) return;
    const pr = portalEl.getBoundingClientRect();
    const cr = cardEl.getBoundingClientRect();
    setDonStackAnchor({ x: cr.left + cr.width / 2 - pr.left, y: cr.bottom - pr.top });
    setDonStackCard(card);
  }
  function hideAttachedDonStack(): void {
    clearDonStackCloseTimer();
    donStackCloseTimerRef.current = window.setTimeout(() => {
      setDonStackCard(null);
      setDonStackAnchor(null);
      donStackCloseTimerRef.current = null;
    }, 160);
  }
  function toggleAttachedDonStack(card: CardView): void {
    if (donStackCard?.instanceId === card.instanceId) {
      clearDonStackCloseTimer();
      setDonStackCard(null);
      setDonStackAnchor(null);
    } else {
      revealAttachedDonStack(card);
    }
  }
  // Safety net: if the mode that made this card's DON!! selectable ends
  // while the stack is still open (e.g. a donMinus choice auto-submits the
  // instant its last DON!! is picked — see useBoardSelection.ts's
  // toggleDonChoiceCard), close the now-stale stack instead of leaving it
  // hovering over the board with nothing left to select.
  useEffect(() => {
    if (donStackCard && !attachedDonSelectable(donStackCard)) {
      clearDonStackCloseTimer();
      setDonStackCard(null);
      setDonStackAnchor(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode.kind]);

  const leaderSlot = leaderCard ? (
    <HoverableFieldCard
      instanceId={leaderCard.instanceId}
      registerEl={registerCardEl}
      active={attachedDonSelectable(leaderCard)}
      onEnter={() => revealAttachedDonStack(leaderCard)}
      onLeave={hideAttachedDonStack}
    >
      <BoardCardTile
        card={leaderCard}
        size="field"
        selectable={leaderCharacterSelectable(mode, isOwn, isOpponent, 'leaderArea', leaderCard, canActivate(leaderCard), canOnOppAttack(leaderCard))}
        selected={attackerSelected.has(leaderCard.instanceId) || fieldChoiceSelected(mode, leaderCard)}
        dimmed={fieldChoiceDimmed(mode, leaderCard)}
        activatable={mode.kind === 'idle' && canActivate(leaderCard)}
        attackable={mode.kind === 'idle' && canAttack(leaderCard)}
        showBattlePower={battlePowerInstanceIds?.has(leaderCard.instanceId)}
        attachedDonSelectable={attachedDonSelectable(leaderCard)}
        attachedDonSelectedCount={selectedAttachedDonCount(leaderCard)}
        onActivate={mode.kind === 'idle' && canActivate(leaderCard) ? () => onCardTap(board.playerId, 'leaderArea', leaderCard) : undefined}
        onAttack={mode.kind === 'idle' && canAttack(leaderCard) ? () => onCardAttack?.(leaderCard) : undefined}
        onAttachedDonSelect={attachedDonSelectable(leaderCard) ? () => toggleAttachedDonStack(leaderCard) : undefined}
        onSelect={() => onCardTap(board.playerId, 'leaderArea', leaderCard)}
        onZoom={() => onCardZoom(leaderCard)}
        onHoverStart={mode.kind === 'selectAttackTarget' && isOpponent ? () => onAttackTargetHover?.(leaderCard) : undefined}
        onHoverEnd={mode.kind === 'selectAttackTarget' && isOpponent ? () => onAttackTargetHover?.(null) : undefined}
        giveDonControls={giveDonControlsFor(leaderCard)}
      />
    </HoverableFieldCard>
  ) : (
    <EmptySlot size="leader" label="Leader" />
  );

  const stageSlot = stageCard ? (
    <BoardCardTile
      card={stageCard}
      size="field"
      selectable={leaderCharacterSelectable(mode, isOwn, isOpponent, 'stageArea', stageCard, canActivate(stageCard), canOnOppAttack(stageCard))}
      dimmed={fieldChoiceDimmed(mode, stageCard)}
      activatable={mode.kind === 'idle' && canActivate(stageCard)}
      showBattlePower={battlePowerInstanceIds?.has(stageCard.instanceId)}
      onActivate={mode.kind === 'idle' && canActivate(stageCard) ? () => onCardTap(board.playerId, 'stageArea', stageCard) : undefined}
      onSelect={() => onCardTap(board.playerId, 'stageArea', stageCard)}
      onZoom={() => onCardZoom(stageCard)}
    />
  ) : (
    <EmptySlot size="board" label="Stage" />
  );

  // Deck used to sit in boardRow next to Stage; it now lives in the
  // Character Area's own row instead, as a separate MatCell sitting BESIDE
  // characterZone (own border/box, own panel) rather than layered inside
  // it — characterZone keeps its own complete bordered box for just the
  // character cards, and deckCell is a plain flex sibling next to it (see
  // the characterRow assembly in `mat` below). flex-shrink-0 keeps Deck at
  // its natural card-pile size while characterZone (flex-1) takes the rest
  // of the row; items-stretch on their shared row makes both boxes match
  // the row's full height, with Deck's own MatCell centering the pile
  // vertically inside that height exactly like every other MatCell does.
  // Anchored to the same edge stageTrashGroup sits on in boardRow below, so
  // Deck stays visually stacked above Stage/Trash rather than landing on a
  // disconnected side.
  const deckCell = (
    <MatCell label="Deck" className="flex-shrink-0" labelClassName="sr-only" style={{ width: BOARD_ZONE_TRACK }} allowOverflow>
      <div data-board-zone="deck" data-board-player={board.playerId}>
        <PileStack label="Deck" count={board.deckCount} variant="deck" size="field" reverseRows={reverseRows} boardFocused={boardFocused} playerId={board.playerId} />
      </div>
    </MatCell>
  );

  const characterZone = (
    <MatCell label="Character Area" className="h-full flex-1" labelClassName="sr-only" allowOverflow>
      <div
        className="flex h-full w-full min-w-0 items-center justify-center gap-2 overflow-visible"
        data-board-zone="characterArea"
        data-board-player={board.playerId}
      >
        {board.characterArea.map((card) => (
          <HoverableFieldCard
            key={card.instanceId}
            instanceId={card.instanceId}
            registerEl={registerCardEl}
            active={attachedDonSelectable(card)}
            onEnter={() => revealAttachedDonStack(card)}
            onLeave={hideAttachedDonStack}
          >
            <BoardCardTile
              card={card}
              size="field"
              selectable={leaderCharacterSelectable(mode, isOwn, isOpponent, 'characterArea', card, canActivate(card), canOnOppAttack(card))}
              selected={attackerSelected.has(card.instanceId) || fieldChoiceSelected(mode, card)}
              dimmed={fieldChoiceDimmed(mode, card)}
              activatable={mode.kind === 'idle' && canActivate(card)}
              attackable={mode.kind === 'idle' && canAttack(card)}
              showBattlePower={battlePowerInstanceIds?.has(card.instanceId)}
              attachedDonSelectable={attachedDonSelectable(card)}
              attachedDonSelectedCount={selectedAttachedDonCount(card)}
              onActivate={mode.kind === 'idle' && canActivate(card) ? () => onCardTap(board.playerId, 'characterArea', card) : undefined}
              onAttack={mode.kind === 'idle' && canAttack(card) ? () => onCardAttack?.(card) : undefined}
              onAttachedDonSelect={attachedDonSelectable(card) ? () => toggleAttachedDonStack(card) : undefined}
              onSelect={() => onCardTap(board.playerId, 'characterArea', card)}
              onZoom={() => onCardZoom(card)}
              onHoverStart={mode.kind === 'selectAttackTarget' && isOpponent && card.orientation === 'rested' ? () => onAttackTargetHover?.(card) : undefined}
              onHoverEnd={mode.kind === 'selectAttackTarget' && isOpponent && card.orientation === 'rested' ? () => onAttackTargetHover?.(null) : undefined}
              giveDonControls={giveDonControlsFor(card)}
            />
          </HoverableFieldCard>
        ))}
        {board.characterArea.length === 0 && (
          // Empty-state watermark. data-zone-empty-hint lets styles/index.css
          // pull it out of flow while a hand-drag landing ghost is portalled
          // into this zone, so the ghost occupies the real card slot instead
          // of sharing the row with the label.
          <span
            data-zone-empty-hint="characterArea"
            className="font-display text-xl font-black uppercase tracking-[0.08em] text-white/20"
          >
            Character Area
          </span>
        )}
      </div>
    </MatCell>
  );

  const characterRow = (
    <div className="flex h-full min-h-0 items-stretch gap-2 overflow-visible">
      {reverseRows ? (
        <>
          {deckCell}
          {characterZone}
        </>
      ) : (
        <>
          {characterZone}
          {deckCell}
        </>
      )}
    </div>
  );

  const leaderCell = <MatCell label="Leader Card" variant="invisible" labelClassName="sr-only">{leaderSlot}</MatCell>;
  // data-board-zone marks this as the Stage drop target for hand drags (see
  // DockHand's play-drop hit-test); the other zones already carry one.
  const stageCell = (
    <MatCell label="Stage Card" variant="invisible" labelClassName="sr-only">
      <div className="flex h-full w-full items-center justify-center" data-board-zone="stageArea" data-board-player={board.playerId}>
        {stageSlot}
      </div>
    </MatCell>
  );
  const trashCell = (
    <MatCell label="Trash" labelClassName="sr-only">
      <TrashPile cards={board.trash} playerId={board.playerId} onClick={() => setTrashGalleryOpen(true)} />
    </MatCell>
  );
  // Active and Rested DON!! both stack sideways now (see DonStack.tsx) and
  // render at full card size, so their wrapper cells go variant="invisible"
  // — no border/background panel, just the chips floating directly on the
  // mat. sr-only label keeps them announced for screen readers regardless.
  const activeDonCell = (
    <MatCell label="Active DON!!" variant="invisible" labelClassName="sr-only">
      <DonStack
        label="Active"
        playerId={board.playerId}
        cards={activeDon}
        direction="horizontal"
        selectable={(card) => donSelectable(mode, isOwn, card)}
        selectedIds={selectedDon}
        onDonSelect={(card) => onCardTap(board.playerId, 'costArea', card)}
        reverseRows={reverseRows}
      />
    </MatCell>
  );
  const restedDonCell = (
    <MatCell label="Rested DON!!" variant="invisible" labelClassName="sr-only">
      <DonStack
        label="Rested"
        playerId={board.playerId}
        cards={restedDon}
        direction="horizontal"
        selectable={(card) => donSelectable(mode, isOwn, card)}
        selectedIds={selectedDon}
        onDonSelect={(card) => onCardTap(board.playerId, 'costArea', card)}
        reverseRows={reverseRows}
      />
    </MatCell>
  );

  // boardRow used to be a flex row where leaderGroup claimed flex-1 and
  // centered itself in whatever space donGroup/stageTrashGroup left behind.
  // That broke once DON!! stacking went uncapped (DonStack.tsx): a growing
  // donGroup ate into the "leftover space" leaderGroup centers in, so Leader
  // visually slid sideways every time a DON!! was added/removed. Leader's
  // screen position must stay put regardless of pile size, and both
  // players' Leaders must land on the same X so they face off across the
  // Battle Line (MatchScreen.tsx) — neither is possible with sibling-width-
  // dependent flex centering.
  //
  // Fix: boardRow is now a `relative` box with a fixed track size (it's
  // still a CSS grid item in `mat` below, so it still stretches to fill its
  // row/column exactly like before). Each group is `absolute` inside it:
  // - donGroup pins to the edge next to Life (right for reversed/top, left
  //   for bottom — same mirroring as before) via left-0/right-0. Being
  //   absolute, it can grow with the pile (DonStack.tsx's now-uncapped span)
  //   without pushing on anything else in the row. Active/Rested swap their
  //   left-right order specifically for the reversed/top row, so the visual
  //   scan order mirrors rather than repeats between the two players.
  // - stageTrashGroup pins to the opposite edge the same way.
  // - leaderGroup pins to left-1/2 + -translate-x-1/2 — dead center of
  //   boardRow's own box, which is sized purely by the mat's grid track, not
  //   by sibling content. That's what makes Leader's position independent of
  //   donGroup's width, and identical between the top and bottom panel
  //   (assuming both panels' boardRow boxes are the same width, which
  //   MatchScreen.tsx's PlayerSideRow now guarantees by giving both rows'
  //   Hand the same fixed column width and pinning it to the same edge).
  // Known limitation: because donGroup/stageTrashGroup no longer participate
  // in flex flow, a very large DON!! pile can grow inward far enough to
  // visually overlap Leader or Stage/Trash instead of pushing them aside.
  // leaderGroup gets z-10 so Leader stays on top if that happens; this is an
  // accepted trade-off for keeping Leader's position stable.
  const donGroup = (
    <div className={['absolute inset-y-0 flex items-stretch gap-0.5', reverseRows ? 'right-0' : 'left-0'].join(' ')}>
      {reverseRows ? (
        <>
          {restedDonCell}
          {activeDonCell}
        </>
      ) : (
        <>
          {activeDonCell}
          {restedDonCell}
        </>
      )}
    </div>
  );

  const stageTrashGroup = (
    <div
      className={['absolute inset-y-0 grid gap-8', reverseRows ? 'left-0' : 'right-0'].join(' ')}
      style={{ gridTemplateColumns: `${BOARD_ZONE_TRACK} ${BOARD_ZONE_TRACK}` }}
    >
      {reverseRows ? (
        <>
          {trashCell}
          {stageCell}
        </>
      ) : (
        <>
          {stageCell}
          {trashCell}
        </>
      )}
    </div>
  );

  // leaderGroup must sit in the horizontal middle of the WHOLE mat, not just
  // of boardRow. boardRow only spans the mat grid's non-Life column, so a
  // plain left-1/2 centers Leader within that column — which lands it off to
  // one side of the true play-field center by exactly half the Life column
  // (plus the grid gap). Worse, since the Life column is mirrored to the
  // opposite edge for the top/reversed panel, that same left-1/2 pushed the
  // two players' Leaders to OPPOSITE sides of center, so they didn't line up
  // across the Battle Line. Anchoring at 50% ± half-the-Life-column (toward
  // the Life edge) puts Leader at the real mat center and makes both panels'
  // Leaders share one X. gap-2 = 0.5rem is the mat grid's column gap.
  const leaderCenterOffset = `calc((${LIFE_COLUMN_TRACK} + 0.5rem) / 2)`;
  const leaderGroup = (
    <div
      className="absolute inset-y-0 z-10 grid -translate-x-1/2"
      style={{
        gridTemplateColumns: BOARD_ZONE_TRACK,
        left: reverseRows ? `calc(50% + ${leaderCenterOffset})` : `calc(50% - ${leaderCenterOffset})`,
      }}
      data-board-zone="leaderArea"
      data-board-player={board.playerId}
    >
      {leaderCell}
    </div>
  );

  const boardRow = (
    <div className="relative min-h-0 h-full w-full">
      {donGroup}
      {leaderGroup}
      {stageTrashGroup}
    </div>
  );

  const mat = (
    <div className="flex min-h-0 flex-1 items-stretch justify-center overflow-hidden">
      <div
        className="grid h-full w-full max-w-full flex-1 grid-rows-2 gap-2 overflow-hidden rounded-xl border border-white/10 bg-[linear-gradient(135deg,_rgba(255,255,255,0.08),_rgba(255,255,255,0.02))] p-2 shadow-inner shadow-black/30"
        style={{ gridTemplateColumns: reverseRows ? `minmax(0,1fr) ${LIFE_COLUMN_TRACK}` : `${LIFE_COLUMN_TRACK} minmax(0,1fr)` }}
      >
        {reverseRows ? (
          <>
            {boardRow}
            <MatCell label="Life" variant="dark" className="row-span-2" labelClassName="sr-only" allowOverflow>
              <LifeStack playerId={board.playerId} life={board.life} count={board.lifeAreaCount} donDeckCount={board.donDeckCount} donDeckFirst />
            </MatCell>
            <div className="min-h-0">{characterRow}</div>
          </>
        ) : (
          <>
            <MatCell label="Life" variant="dark" className="row-span-2" labelClassName="sr-only" allowOverflow>
              <LifeStack playerId={board.playerId} life={board.life} count={board.lifeAreaCount} donDeckCount={board.donDeckCount} />
            </MatCell>
            {/* relative z-10: characterRow must paint above boardRow (which comes later in DOM
                and would otherwise cover the deck ghost layers that extend downward into row 1) */}
            <div className="relative z-10 min-h-0">{characterRow}</div>
            {boardRow}
          </>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex h-full min-h-0 min-w-0 flex-1 flex-col" data-board-player={board.playerId}>
      {mat}
      <TrashGalleryModal
        open={trashGalleryOpen}
        onClose={() => setTrashGalleryOpen(false)}
        playerId={board.playerId}
        cards={board.trash}
        onCardZoom={onCardZoom}
      />
      <AttachedDonHoverStack
        anchor={donStackAnchor}
        cards={(donStackCard?.donAttachedIds ?? []).map((id) => donCardById.get(id)).filter((don): don is CardView => !!don)}
        selectable={(don) => donSelectable(mode, isOwn, don)}
        selectedIds={selectedDon}
        onSelect={(don) => onCardTap(board.playerId, 'attachedDon', don)}
        onMouseEnter={clearDonStackCloseTimer}
        onMouseLeave={hideAttachedDonStack}
        donArtUrl={donArtUrl}
      />
    </div>
  );
});
