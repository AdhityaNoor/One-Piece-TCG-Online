import type { CardLibraryEntry } from '../../../cards/library';
import { copyLimitForCard } from '../../../cards/decks';
import { CardDetailModal, CardImage } from '../../components';
import { useDeckBuilderStore } from '../../store/deckBuilderStore';
import { useState } from 'react';
import { PrintingPickerButton, PrintingPickerModal } from './PrintingPickerModal';

export interface DeckBuilderResultTileProps {
  entry: CardLibraryEntry;
}

export const DECK_BUILDER_CARD_DRAG_MIME = 'application/x-optcg-deck-builder-card';

export interface DeckBuilderCardDragPayload {
  cardNumber: string;
  printingImageId: string;
}

export function DeckBuilderResultTile({ entry }: DeckBuilderResultTileProps) {
  const [zoomOpen, setZoomOpen] = useState(false);
  const [artPickerOpen, setArtPickerOpen] = useState(false);
  const [selectedPrintingImageId, setSelectedPrintingImageId] = useState(entry.printings[0]?.printingImageId ?? entry.cardNumber);
  const leaderSelection = useDeckBuilderStore((state) => state.leaderSelection);
  const mainDeckSelections = useDeckBuilderStore((state) => state.mainDeckSelections);
  const setLeader = useDeckBuilderStore((state) => state.setLeader);
  const addMainDeckCard = useDeckBuilderStore((state) => state.addMainDeckCard);

  const isLeaderCard = entry.definition.category === 'leader';
  const isCurrentLeader = isLeaderCard && leaderSelection?.libraryEntry.cardNumber === entry.cardNumber;
  const currentLeaderPrintingId = isCurrentLeader ? leaderSelection.chosenPrintingImageId : selectedPrintingImageId;
  const activePrintingImageId = isCurrentLeader ? currentLeaderPrintingId : selectedPrintingImageId;
  const selectedPrinting = entry.printings.find((printing) => printing.printingImageId === activePrintingImageId) ?? entry.printings[0] ?? null;
  const mainDeckMatch = mainDeckSelections.find((s) => s.chosenPrintingImageId === selectedPrintingImageId);
  const quantity = mainDeckMatch?.quantity ?? 0;
  const totalQuantityForCardNumber = mainDeckSelections
    .filter((s) => s.libraryEntry.cardNumber === entry.cardNumber)
    .reduce((sum, selection) => sum + selection.quantity, 0);
  const hasLeader = leaderSelection !== null;
  const imageUrl = selectedPrinting?.imageUrl ?? null;
  // 5-1-2-3: normally 4, but Infinity for "any number of this card" cards (e.g. Pacifista).
  const copyLimit = copyLimitForCard(entry.definition);
  const atCopyLimit = totalQuantityForCardNumber >= copyLimit;
  const canDrag = isLeaderCard ? !(isCurrentLeader && leaderSelection?.chosenPrintingImageId === selectedPrintingImageId) : hasLeader && !atCopyLimit;

  function handleSelect() {
    if (isLeaderCard) {
      setLeader(entry, selectedPrintingImageId);
      return;
    }
    if (hasLeader && !atCopyLimit) addMainDeckCard(entry, selectedPrintingImageId, 1);
  }

  return (
    <>
      <div className="w-full sm:w-[8.5rem]">
        <div
          onContextMenu={(event) => {
            event.preventDefault();
            setZoomOpen(true);
          }}
          draggable={canDrag}
          onDragStart={(event) => {
            if (!canDrag) {
              event.preventDefault();
              return;
            }
            const payload: DeckBuilderCardDragPayload = {
              cardNumber: entry.cardNumber,
              printingImageId: selectedPrintingImageId,
            };
            event.dataTransfer.effectAllowed = 'copy';
            event.dataTransfer.setData(DECK_BUILDER_CARD_DRAG_MIME, JSON.stringify(payload));
            event.dataTransfer.setData('text/plain', `${entry.cardNumber} ${entry.definition.name}`);
          }}
          onClick={handleSelect}
          className={['group relative block w-full text-left', canDrag ? 'cursor-grab active:cursor-grabbing' : '', !isLeaderCard && (!hasLeader || atCopyLimit) ? 'opacity-55' : ''].join(' ')}
          title={isLeaderCard ? (isCurrentLeader ? 'Current leader' : 'Drag or click to set leader') : hasLeader ? 'Drag or click to add to deck' : 'Pick a leader first'}
        >
          <CardImage src={imageUrl} alt={entry.definition.name} className="rounded-none" />
          {totalQuantityForCardNumber > 0 && (
            <span className="absolute bottom-1 right-1 border border-[rgb(var(--op-gold-rgb)/0.4)] bg-black/80 px-1.5 py-0.5 font-heading text-[10px] font-bold text-white">
              {totalQuantityForCardNumber}x
            </span>
          )}
          {isLeaderCard && (
            <span className="absolute left-1 top-1 border border-black/40 bg-[rgb(var(--op-gold-rgb))] px-1.5 py-0.5 font-heading text-[9px] font-black uppercase tracking-[0.08em] text-black shadow-[2px_2px_0_rgba(0,0,0,0.45)]">
              {isCurrentLeader ? 'Leader' : 'Set'}
            </span>
          )}
          <div className="absolute inset-0 flex items-center justify-center gap-2 bg-black/40 opacity-100 transition sm:bg-black/0 sm:opacity-0 sm:group-hover:bg-black/55 sm:group-hover:opacity-100">
            <button
              type="button"
              onClick={(event) => {
                event.stopPropagation();
                setZoomOpen(true);
              }}
              className="border border-[rgb(var(--op-gold-rgb)/0.5)] bg-white px-2.5 py-1 font-heading text-[10px] font-black uppercase tracking-[0.08em] text-navy-950 shadow-[0_5px_0_rgba(0,0,0,0.45)] transition hover:bg-[rgb(var(--op-gold-rgb))] active:translate-y-[2px]"
            >
              View
            </button>
            <button
              type="button"
              onClick={(event) => {
                event.stopPropagation();
                handleSelect();
              }}
              disabled={isLeaderCard ? isCurrentLeader && leaderSelection?.chosenPrintingImageId === selectedPrintingImageId : !hasLeader || atCopyLimit}
              className="flex h-8 min-w-8 items-center justify-center border border-[rgb(var(--op-gold-rgb)/0.7)] bg-[rgb(var(--op-gold-rgb))] px-2 font-heading text-sm font-black text-black shadow-[0_5px_0_rgba(68,39,0,0.75)] transition hover:brightness-125 active:translate-y-[2px] disabled:cursor-not-allowed disabled:opacity-45"
              title={isLeaderCard ? (isCurrentLeader ? 'Current leader' : 'Set leader') : 'Add one copy'}
            >
              {isLeaderCard ? 'Set' : '+'}
            </button>
          </div>
          {/* Alternate arts open a real picker instead of the old 28px-wide overlay strip. */}
          <div className="pointer-events-none absolute inset-x-1 bottom-1 z-20 flex justify-center">
            <div className="pointer-events-auto">
              <PrintingPickerButton count={entry.printings.length} onClick={() => setArtPickerOpen(true)} />
            </div>
          </div>
          <span className="pointer-events-none absolute inset-0 ring-0 ring-[rgb(var(--op-gold-rgb))] transition group-hover:ring-2" />
        </div>
      </div>
      <CardDetailModal open={zoomOpen} onClose={() => setZoomOpen(false)} definition={entry.definition} imageUrl={imageUrl} setName={selectedPrinting?.setName} accentClassName="op-theme-blue" />
      <PrintingPickerModal
        open={artPickerOpen}
        onClose={() => setArtPickerOpen(false)}
        cardName={entry.definition.name}
        cardNumber={entry.cardNumber}
        printings={entry.printings}
        selectedPrintingImageId={activePrintingImageId}
        onSelect={(printingImageId) => {
          setSelectedPrintingImageId(printingImageId);
          if (isCurrentLeader) setLeader(entry, printingImageId);
        }}
      />
    </>
  );
}
