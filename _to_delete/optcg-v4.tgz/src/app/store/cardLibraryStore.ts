import { create } from 'zustand';
import {
  withCache,
  type CardApiError,
  type CardPrintingDto,
  type SetSummaryDto,
} from '../../cards/api';
import { fetchAllSets, fetchAllPlayableCardPrintings, fetchSetCards, resolveCardPrintingsById } from '../lib/cardCatalog';
import {
  buildCardLibraryEntry,
  filterCardLibraryEntries,
  groupPrintingsByCardNumber,
  groupPrintingsIntoLibraryEntries,
  normalizeTypeTags,
  type CardLibraryEntry,
  type CardLibraryFilter,
} from '../../cards/library';
import { browserFetch, cardLibraryCache, CARD_LIBRARY_CACHE_TTL_MS } from '../lib/runtime';

export const CARD_LIBRARY_PAGE_SIZE = 30;
export const ALL_SETS_ID = 'all';

type LoadStatus = 'idle' | 'loading' | 'loaded' | 'error';
type SearchByIdStatus = 'idle' | 'loading' | 'found' | 'not-found' | 'error';

interface CardLibraryState {
  sets: SetSummaryDto[];
  setsStatus: LoadStatus;
  setsError?: CardApiError;
  selectedSetId: string;
  entriesBySetId: Record<string, CardLibraryEntry[]>;
  setStatusById: Record<string, LoadStatus>;
  setErrorById: Record<string, CardApiError>;
  filter: CardLibraryFilter;
  visibleCount: number;
  selectedCardNumber: string | null;
  searchById: { queryId: string; status: SearchByIdStatus; result: CardLibraryEntry | null; error?: CardApiError };
  loadSets(): Promise<void>;
  selectSet(setId: string): void;
  loadSetCards(setId: string): Promise<void>;
  setFilter(filter: CardLibraryFilter): void;
  loadMore(): void;
  /**
   * Set the visible window directly. The results grid uses this to keep the window a whole
   * number of GRID COLUMNS, so the last row is never a ragged half-row — the column count is
   * only knowable from the laid-out DOM (the grid is `auto-fill`), so the store cannot derive
   * it and the caller passes the already-rounded total. Never shrinks below one page.
   */
  setVisibleCount(count: number): void;
  selectCard(cardNumber: string | null): void;
  searchByCardId(cardId: string): Promise<void>;
}

const ALL_SETS_ENTRY: SetSummaryDto = { set_id: ALL_SETS_ID, set_name: 'All Sets' };

export const useCardLibraryStore = create<CardLibraryState>((set, get) => ({
  sets: [],
  setsStatus: 'idle',
  selectedSetId: ALL_SETS_ID,
  entriesBySetId: {},
  setStatusById: {},
  setErrorById: {},
  filter: {},
  visibleCount: CARD_LIBRARY_PAGE_SIZE,
  selectedCardNumber: null,
  searchById: { queryId: '', status: 'idle', result: null },

  loadSets: async () => {
    if (get().setsStatus === 'loading' || get().setsStatus === 'loaded') return;
    set({ setsStatus: 'loading', setsError: undefined });
    const result = await withCache<SetSummaryDto[]>(cardLibraryCache, 'allSets', () => fetchAllSets(browserFetch), {
      ttlMs: CARD_LIBRARY_CACHE_TTL_MS,
    });
    if (result.ok) set({ sets: [ALL_SETS_ENTRY, ...[...result.data].reverse()], setsStatus: 'loaded' });
    else set({ setsStatus: 'error', setsError: result.error as CardApiError });
  },

  selectSet: (setId) => {
    set({ selectedSetId: setId, visibleCount: CARD_LIBRARY_PAGE_SIZE });
    const status = get().setStatusById[setId];
    if (status !== 'loading' && status !== 'loaded') void get().loadSetCards(setId);
  },

  loadSetCards: async (setId) => {
    set((state) => ({ setStatusById: { ...state.setStatusById, [setId]: 'loading' } }));
    const result =
      setId === ALL_SETS_ID
        ? await withCache<CardPrintingDto[]>(cardLibraryCache, 'allPlayableCardPrintings', () => fetchAllPlayableCardPrintings(browserFetch), {
            ttlMs: CARD_LIBRARY_CACHE_TTL_MS,
          })
        : await withCache<CardPrintingDto[]>(cardLibraryCache, `setCards:${setId}`, () => fetchSetCards(browserFetch, setId), {
            ttlMs: CARD_LIBRARY_CACHE_TTL_MS,
          });
    if (result.ok) {
      const entries = setId === ALL_SETS_ID ? groupPrintingsIntoLibraryEntries(result.data) : groupPrintingsByCardNumber(result.data).map(buildCardLibraryEntry);
      set((state) => ({
        entriesBySetId: { ...state.entriesBySetId, [setId]: entries },
        setStatusById: { ...state.setStatusById, [setId]: 'loaded' },
      }));
    } else {
      set((state) => ({
        setStatusById: { ...state.setStatusById, [setId]: 'error' },
        setErrorById: { ...state.setErrorById, [setId]: result.error as CardApiError },
      }));
    }
  },

  setFilter: (filter) => set({ filter, visibleCount: CARD_LIBRARY_PAGE_SIZE }),
  loadMore: () => set((state) => ({ visibleCount: state.visibleCount + CARD_LIBRARY_PAGE_SIZE })),
  setVisibleCount: (count) => set((state) => {
    const next = Math.max(CARD_LIBRARY_PAGE_SIZE, Math.floor(count));
    return next === state.visibleCount ? {} : { visibleCount: next };
  }),
  selectCard: (cardNumber) => set({ selectedCardNumber: cardNumber }),
  searchByCardId: async (cardId) => {
    const normalized = cardId.trim().toUpperCase();
    set({ searchById: { queryId: normalized, status: 'loading', result: null } });
    if (normalized.length === 0) {
      set({ searchById: { queryId: normalized, status: 'idle', result: null } });
      return;
    }
    const result = await resolveCardPrintingsById(browserFetch, normalized);
    if (!result.ok) {
      set({ searchById: { queryId: normalized, status: 'error', result: null, error: result.error } });
      return;
    }
    if (!result.found) {
      set({ searchById: { queryId: normalized, status: 'not-found', result: null } });
      return;
    }
    set({ searchById: { queryId: normalized, status: 'found', result: buildCardLibraryEntry(result.printings) } });
  },
}));

/**
 * Memoization for the derived-card selectors below.
 *
 * These hooks used to call filterCardLibraryEntries(all, filter) directly
 * inside the Zustand selector. Zustand runs every selector on every store
 * change, and these returned a fresh array/derived value each time — so any
 * unrelated state update (audio, navigation, another store slice) re-ran a
 * full O(n) scan of the entire card database (thousands of entries for the
 * "All Sets" view) AND returned a new reference, forcing the whole card grid
 * to re-render. On the deck-builder / card-library screens that lands
 * squarely in the interaction→next-paint window and inflates INP.
 *
 * Both `all` (entriesBySetId[selectedSetId]) and `filter` are stable object
 * references between the actions that actually change them, so a single-entry
 * cache keyed on their identities lets the selector return the SAME reference
 * across unrelated updates. React then bails out of the re-render and the
 * filter runs at most once per real (entries, filter) change instead of once
 * per store update — and only once, not twice (visible + count now share it).
 */
const EMPTY_ENTRIES: CardLibraryEntry[] = [];

let filteredCache: { all: CardLibraryEntry[]; filter: CardLibraryFilter; result: CardLibraryEntry[] } | null = null;
function getFilteredEntries(all: CardLibraryEntry[], filter: CardLibraryFilter): CardLibraryEntry[] {
  if (filteredCache && filteredCache.all === all && filteredCache.filter === filter) return filteredCache.result;
  const result = filterCardLibraryEntries(all, filter);
  filteredCache = { all, filter, result };
  return result;
}

let visibleCache: { filtered: CardLibraryEntry[]; visibleCount: number; result: CardLibraryEntry[] } | null = null;
function getVisibleEntries(filtered: CardLibraryEntry[], visibleCount: number): CardLibraryEntry[] {
  if (visibleCache && visibleCache.filtered === filtered && visibleCache.visibleCount === visibleCount) return visibleCache.result;
  // Avoid re-slicing (and allocating) when the page already shows everything.
  const result = visibleCount >= filtered.length ? filtered : filtered.slice(0, visibleCount);
  visibleCache = { filtered, visibleCount, result };
  return result;
}

let typesCache: { all: CardLibraryEntry[]; result: string[] } | null = null;
function getKnownTypes(all: CardLibraryEntry[]): string[] {
  if (typesCache && typesCache.all === all) return typesCache.result;
  const byLower = new Map<string, string>();
  for (const entry of all) {
    for (const type of normalizeTypeTags(entry.definition.types)) {
      const key = type.toLowerCase();
      if (!byLower.has(key)) byLower.set(key, type);
    }
  }
  const result = [...byLower.values()].sort((a, b) => a.localeCompare(b));
  typesCache = { all, result };
  return result;
}

export function useVisibleCardLibraryEntries(): CardLibraryEntry[] {
  return useCardLibraryStore((state) => {
    const all = state.entriesBySetId[state.selectedSetId] ?? EMPTY_ENTRIES;
    return getVisibleEntries(getFilteredEntries(all, state.filter), state.visibleCount);
  });
}

export function useFilteredCardLibraryCount(): number {
  return useCardLibraryStore((state) => {
    const all = state.entriesBySetId[state.selectedSetId] ?? EMPTY_ENTRIES;
    return getFilteredEntries(all, state.filter).length;
  });
}

export function useKnownCardLibraryTypes(): string[] {
  return useCardLibraryStore((state) => {
    const all = state.entriesBySetId[state.selectedSetId] ?? EMPTY_ENTRIES;
    return getKnownTypes(all);
  });
}
