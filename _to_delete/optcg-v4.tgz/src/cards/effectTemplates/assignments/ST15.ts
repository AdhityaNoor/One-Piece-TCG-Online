/**
 * Reviewed effect template assignments - Starter Deck ST15 (triage batch).
 * Structural params only; never copy raw effect text into assignments.
 */
import type { CardEffectAssignment } from '../assembler';

export const ST15_ASSIGNMENTS: CardEffectAssignment[] = [
  // ST15-001 (character) Atmos —
  //   [When Attacking] If your Leader is [Edward.Newgate], you cannot add Life cards to your hand using
  //   your own effects during this turn.
  {
    cardNumber: 'ST15-001',
    templateId: 'ability',
    params: {
      timing: 'whenAttacking',
      gate: [{ kind: 'leaderName', name: 'Edward.Newgate' }],
      functions: [{ fn: 'preventControllerLifeToHand', duration: 'duringThisTurn' }],
    },
  },

  // ST15-002 — [On Play] give up to 1 rested DON!! to Leader/1 Char. [Activate: Main] rest this: K.O. up to 1 opp Character 5000 power or less.
  {
    cardNumber: 'ST15-002',
    templates: [
      { templateId: 'ability', params: { timing: 'onPlay', functions: [{ fn: 'giveDon', count: 1 }] } },
      { templateId: 'ability', params: { timing: 'activateMain', cost: [{ kind: 'restThis' }], functions: [{ fn: 'ko', target: { group: 'characters', player: 'opponent', filter: { maxPower: 5000 } }, optional: true }] } },
    ],
  },

  // ST15-003 (character) Kingdew — [Blocker] printed. [Opponent's Turn] K.O.'d by effect → Leader +2000.
  {
    cardNumber: 'ST15-003',
    templateId: 'ability',
    params: {
      timing: 'onKO',
      condition: { turn: 'opponent' },
      gate: [{ kind: 'koByEffect' }],
      functions: [{ fn: 'addPower', target: { group: 'leader', player: 'controller' }, amount: 2000, duration: 'duringThisTurn', optional: true }],
    },
  },

  // ST15-004 — [On Play] If Leader {Whitebeard Pirates}, give up to 1 opp Character −2000, then add 1 top Life to hand.
  { cardNumber: 'ST15-004', templateId: 'ability', params: { timing: 'onPlay', gate: [{ kind: 'leaderType', type: 'Whitebeard Pirates' }], functions: [{ fn: 'addPower', target: { group: 'characters', player: 'opponent' }, amount: -2000, duration: 'duringThisTurn', optional: true }, { fn: 'moveCards', from: { zone: 'life', player: 'controller', position: 'top' }, to: { zone: 'hand', player: 'owner' } }] } },

  // ST15-005 — Closed 2026-07-16 field-removal replacement pass: static [Rush] if Leader {Whitebeard Pirates}, plus the
  // K.O.-replacement (self −2000 power, OPT) via registerKoReplacementSelf.
  { cardNumber: 'ST15-005', templateId: 'ability', params: { timing: 'onEnterPlay', functions: [
    { fn: 'addKeyword', target: { ref: 'self' }, keyword: 'rush', duration: 'permanent', condition: { gate: [{ kind: 'leaderType', type: 'Whitebeard Pirates' }] } },
    { fn: 'registerKoReplacementSelf', scope: 'effect', oncePerTurn: true, replacementTriggers: ['ko', 'returnToHand', 'bottomDeck'], effectSourceController: 'opponent', giveSelfPowerPenalty: { amount: 2000, duration: 'duringThisTurn' }, duration: 'permanent' },
  ] } },
];
