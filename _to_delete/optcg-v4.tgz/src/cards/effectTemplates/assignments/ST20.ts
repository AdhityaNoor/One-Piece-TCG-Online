/**
 * Reviewed effect template assignments - Starter Deck ST20 (triage batch).
 * Structural params only; never copy raw effect text into assignments.
 */
import type { CardEffectAssignment } from '../assembler';

export const ST20_ASSIGNMENTS: CardEffectAssignment[] = [
  // ST20-001 — [Activate: Main] [OPT] turn 1 top Life face-up → give up to 1 rested DON!!.
  { cardNumber: 'ST20-001', templateId: 'ability', params: { timing: 'activateMain', oncePerTurn: true, functions: [
    { fn: 'turnTopLifeFace', faceUp: true },
    { fn: 'giveDon', count: 1, ifPrevious: 'previousSelectedAny' },
  ] } },

  // ST20-002 — Closed 2026-07-16 field-removal replacement pass: [Trigger] trash 1 → play this card, plus the
  // effect-K.O. replacement (trash top Life instead, OPT) via registerKoReplacementSelf.
  { cardNumber: 'ST20-002', templates: [
    { templateId: 'ability', params: { timing: 'lifeTrigger', functions: [{ fn: 'optionalTrashFromHand', count: 1 }, { fn: 'triggerPlaySelf', ifPrevious: 'previousMovedAny' }] } },
    { templateId: 'ability', params: { timing: 'onEnterPlay', functions: [{ fn: 'registerKoReplacementSelf', scope: 'effect', oncePerTurn: true, trashLife: { position: 'top' }, duration: 'permanent' }] } },
  ] },

  // ST20-003 — [Trigger] peek 1 of your/opp's top Life, place top or bottom, then add this card to hand.
  { cardNumber: 'ST20-003', templateId: 'ability', params: { timing: 'lifeTrigger', functions: [
    { fn: 'peekLifeAndPlace', from: 'controllerOrOpponentTop', placement: 'topOrBottom' },
    { fn: 'returnSelfToHand' },
  ] } },

  // ST20-004 — [On Play] add 1 top Life to hand → set up to 1 {Big Mom Pirates} cost ≤3 active. [Trigger] rest up to 1 opp Character cost ≤3.
  {
    cardNumber: 'ST20-004',
    templates: [
      { templateId: 'ability', params: { timing: 'onPlay', functions: [{ fn: 'moveCards', from: { zone: 'life', player: 'controller', position: 'top' }, to: { zone: 'hand', player: 'owner' }, optional: true }, { fn: 'setActiveControllerCharacter', maxTargets: 1, filter: { typeIncludes: 'Big Mom Pirates', maxCost: 3 } }] } },
      { templateId: 'ability', params: { timing: 'lifeTrigger', functions: [{ fn: 'rest', target: { group: 'characters', player: 'opponent', filter: { maxCost: 3 } }, optional: true }] } },
    ],
  },

  // ST20-005 — [On Play] trash 1 from hand → opponent chooses trash 2 from hand or trash 1 opp Life top.
  {
    cardNumber: 'ST20-005',
    templateId: 'ability',
    params: {
      timing: 'onPlay',
      functions: [
        { fn: 'optionalTrashFromHand', count: 1 },
        {
          fn: 'chooseOne',
          chooser: 'opponent',
          prompt: 'Choose one effect to resolve.',
          ifPrevious: 'previousSelectedAny',
          options: [
            { label: 'trashOpponentHand', functions: [{ fn: 'trashFromOpponentHandChosenByOpponent', count: 2 }] },
            { label: 'trashOpponentLifeTop', functions: [{ fn: 'moveCards', from: { zone: 'life', player: 'opponent', position: 'top', count: 1 }, to: { zone: 'trash', player: 'owner' } }] },
          ],
        },
      ],
    },
  },
];
